gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDBarrierObjects3_1final = [];

gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final = [];

gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final = [];

gdjs.Game_32SceneCode.GDContainerObjects3_1final = [];

gdjs.Game_32SceneCode.GDCrateObjects3_1final = [];

gdjs.Game_32SceneCode.GDElfoObjects2_1final = [];

gdjs.Game_32SceneCode.GDEnemyObjects3_1final = [];

gdjs.Game_32SceneCode.GDHumanoObjects2_1final = [];

gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final = [];

gdjs.Game_32SceneCode.GDObstacleObjects3_1final = [];

gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final = [];

gdjs.Game_32SceneCode.GDPlayerObjects2_1final = [];

gdjs.Game_32SceneCode.GDPlayerObjects3_1final = [];

gdjs.Game_32SceneCode.GDPushableBoxObjects3_1final = [];

gdjs.Game_32SceneCode.GDRockObjects3_1final = [];

gdjs.Game_32SceneCode.GDSandbagsObjects3_1final = [];

gdjs.Game_32SceneCode.GDShootButtonObjects1_1final = [];

gdjs.Game_32SceneCode.GDTerrainObjects3_1final = [];

gdjs.Game_32SceneCode.GDWaterTankObjects3_1final = [];

gdjs.Game_32SceneCode.GDZorroObjects2_1final = [];

gdjs.Game_32SceneCode.forEachIndex3 = 0;

gdjs.Game_32SceneCode.forEachObjects3 = [];

gdjs.Game_32SceneCode.forEachTemporary3 = null;

gdjs.Game_32SceneCode.forEachTotalCount3 = 0;

gdjs.Game_32SceneCode.GDObstacleObjects1= [];
gdjs.Game_32SceneCode.GDObstacleObjects2= [];
gdjs.Game_32SceneCode.GDObstacleObjects3= [];
gdjs.Game_32SceneCode.GDObstacleObjects4= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects1= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects2= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects3= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects4= [];
gdjs.Game_32SceneCode.GDMovementJoystickObjects1= [];
gdjs.Game_32SceneCode.GDMovementJoystickObjects2= [];
gdjs.Game_32SceneCode.GDMovementJoystickObjects3= [];
gdjs.Game_32SceneCode.GDMovementJoystickObjects4= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects1= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects2= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects3= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects4= [];
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDPlayerObjects3= [];
gdjs.Game_32SceneCode.GDPlayerObjects4= [];
gdjs.Game_32SceneCode.GDControlsToggleObjects1= [];
gdjs.Game_32SceneCode.GDControlsToggleObjects2= [];
gdjs.Game_32SceneCode.GDControlsToggleObjects3= [];
gdjs.Game_32SceneCode.GDControlsToggleObjects4= [];
gdjs.Game_32SceneCode.GDEnemyObjects1= [];
gdjs.Game_32SceneCode.GDEnemyObjects2= [];
gdjs.Game_32SceneCode.GDEnemyObjects3= [];
gdjs.Game_32SceneCode.GDEnemyObjects4= [];
gdjs.Game_32SceneCode.GDGunObjects1= [];
gdjs.Game_32SceneCode.GDGunObjects2= [];
gdjs.Game_32SceneCode.GDGunObjects3= [];
gdjs.Game_32SceneCode.GDGunObjects4= [];
gdjs.Game_32SceneCode.GDCrosshairObjects1= [];
gdjs.Game_32SceneCode.GDCrosshairObjects2= [];
gdjs.Game_32SceneCode.GDCrosshairObjects3= [];
gdjs.Game_32SceneCode.GDCrosshairObjects4= [];
gdjs.Game_32SceneCode.GDShootButtonObjects1= [];
gdjs.Game_32SceneCode.GDShootButtonObjects2= [];
gdjs.Game_32SceneCode.GDShootButtonObjects3= [];
gdjs.Game_32SceneCode.GDShootButtonObjects4= [];
gdjs.Game_32SceneCode.GDHitParticleObjects1= [];
gdjs.Game_32SceneCode.GDHitParticleObjects2= [];
gdjs.Game_32SceneCode.GDHitParticleObjects3= [];
gdjs.Game_32SceneCode.GDHitParticleObjects4= [];
gdjs.Game_32SceneCode.GDTerrainObjects1= [];
gdjs.Game_32SceneCode.GDTerrainObjects2= [];
gdjs.Game_32SceneCode.GDTerrainObjects3= [];
gdjs.Game_32SceneCode.GDTerrainObjects4= [];
gdjs.Game_32SceneCode.GDMapLimitObjects1= [];
gdjs.Game_32SceneCode.GDMapLimitObjects2= [];
gdjs.Game_32SceneCode.GDMapLimitObjects3= [];
gdjs.Game_32SceneCode.GDMapLimitObjects4= [];
gdjs.Game_32SceneCode.GDGrassObjects1= [];
gdjs.Game_32SceneCode.GDGrassObjects2= [];
gdjs.Game_32SceneCode.GDGrassObjects3= [];
gdjs.Game_32SceneCode.GDGrassObjects4= [];
gdjs.Game_32SceneCode.GDSandbagsObjects1= [];
gdjs.Game_32SceneCode.GDSandbagsObjects2= [];
gdjs.Game_32SceneCode.GDSandbagsObjects3= [];
gdjs.Game_32SceneCode.GDSandbagsObjects4= [];
gdjs.Game_32SceneCode.GDBarrierObjects1= [];
gdjs.Game_32SceneCode.GDBarrierObjects2= [];
gdjs.Game_32SceneCode.GDBarrierObjects3= [];
gdjs.Game_32SceneCode.GDBarrierObjects4= [];
gdjs.Game_32SceneCode.GDContainerObjects1= [];
gdjs.Game_32SceneCode.GDContainerObjects2= [];
gdjs.Game_32SceneCode.GDContainerObjects3= [];
gdjs.Game_32SceneCode.GDContainerObjects4= [];
gdjs.Game_32SceneCode.GDCrateObjects1= [];
gdjs.Game_32SceneCode.GDCrateObjects2= [];
gdjs.Game_32SceneCode.GDCrateObjects3= [];
gdjs.Game_32SceneCode.GDCrateObjects4= [];
gdjs.Game_32SceneCode.GDWaterTankObjects1= [];
gdjs.Game_32SceneCode.GDWaterTankObjects2= [];
gdjs.Game_32SceneCode.GDWaterTankObjects3= [];
gdjs.Game_32SceneCode.GDWaterTankObjects4= [];
gdjs.Game_32SceneCode.GDRockObjects1= [];
gdjs.Game_32SceneCode.GDRockObjects2= [];
gdjs.Game_32SceneCode.GDRockObjects3= [];
gdjs.Game_32SceneCode.GDRockObjects4= [];
gdjs.Game_32SceneCode.GDSmallRocksObjects1= [];
gdjs.Game_32SceneCode.GDSmallRocksObjects2= [];
gdjs.Game_32SceneCode.GDSmallRocksObjects3= [];
gdjs.Game_32SceneCode.GDSmallRocksObjects4= [];
gdjs.Game_32SceneCode.GDCactiObjects1= [];
gdjs.Game_32SceneCode.GDCactiObjects2= [];
gdjs.Game_32SceneCode.GDCactiObjects3= [];
gdjs.Game_32SceneCode.GDCactiObjects4= [];
gdjs.Game_32SceneCode.GDPlantsObjects1= [];
gdjs.Game_32SceneCode.GDPlantsObjects2= [];
gdjs.Game_32SceneCode.GDPlantsObjects3= [];
gdjs.Game_32SceneCode.GDPlantsObjects4= [];
gdjs.Game_32SceneCode.GDPanelDialogoObjects1= [];
gdjs.Game_32SceneCode.GDPanelDialogoObjects2= [];
gdjs.Game_32SceneCode.GDPanelDialogoObjects3= [];
gdjs.Game_32SceneCode.GDPanelDialogoObjects4= [];
gdjs.Game_32SceneCode.GDTextoNombreObjects1= [];
gdjs.Game_32SceneCode.GDTextoNombreObjects2= [];
gdjs.Game_32SceneCode.GDTextoNombreObjects3= [];
gdjs.Game_32SceneCode.GDTextoNombreObjects4= [];
gdjs.Game_32SceneCode.GDTextoDialogoObjects1= [];
gdjs.Game_32SceneCode.GDTextoDialogoObjects2= [];
gdjs.Game_32SceneCode.GDTextoDialogoObjects3= [];
gdjs.Game_32SceneCode.GDTextoDialogoObjects4= [];
gdjs.Game_32SceneCode.GDTextoMisionObjects1= [];
gdjs.Game_32SceneCode.GDTextoMisionObjects2= [];
gdjs.Game_32SceneCode.GDTextoMisionObjects3= [];
gdjs.Game_32SceneCode.GDTextoMisionObjects4= [];
gdjs.Game_32SceneCode.GDBotonSiguienteObjects1= [];
gdjs.Game_32SceneCode.GDBotonSiguienteObjects2= [];
gdjs.Game_32SceneCode.GDBotonSiguienteObjects3= [];
gdjs.Game_32SceneCode.GDBotonSiguienteObjects4= [];
gdjs.Game_32SceneCode.GDBotonHablarObjects1= [];
gdjs.Game_32SceneCode.GDBotonHablarObjects2= [];
gdjs.Game_32SceneCode.GDBotonHablarObjects3= [];
gdjs.Game_32SceneCode.GDBotonHablarObjects4= [];
gdjs.Game_32SceneCode.GDPinoObjects1= [];
gdjs.Game_32SceneCode.GDPinoObjects2= [];
gdjs.Game_32SceneCode.GDPinoObjects3= [];
gdjs.Game_32SceneCode.GDPinoObjects4= [];
gdjs.Game_32SceneCode.GDRobleObjects1= [];
gdjs.Game_32SceneCode.GDRobleObjects2= [];
gdjs.Game_32SceneCode.GDRobleObjects3= [];
gdjs.Game_32SceneCode.GDRobleObjects4= [];
gdjs.Game_32SceneCode.GDArbustoObjects1= [];
gdjs.Game_32SceneCode.GDArbustoObjects2= [];
gdjs.Game_32SceneCode.GDArbustoObjects3= [];
gdjs.Game_32SceneCode.GDArbustoObjects4= [];
gdjs.Game_32SceneCode.GDSetaObjects1= [];
gdjs.Game_32SceneCode.GDSetaObjects2= [];
gdjs.Game_32SceneCode.GDSetaObjects3= [];
gdjs.Game_32SceneCode.GDSetaObjects4= [];
gdjs.Game_32SceneCode.GDTroncoObjects1= [];
gdjs.Game_32SceneCode.GDTroncoObjects2= [];
gdjs.Game_32SceneCode.GDTroncoObjects3= [];
gdjs.Game_32SceneCode.GDTroncoObjects4= [];
gdjs.Game_32SceneCode.GDHelechosObjects1= [];
gdjs.Game_32SceneCode.GDHelechosObjects2= [];
gdjs.Game_32SceneCode.GDHelechosObjects3= [];
gdjs.Game_32SceneCode.GDHelechosObjects4= [];
gdjs.Game_32SceneCode.GDFloresObjects1= [];
gdjs.Game_32SceneCode.GDFloresObjects2= [];
gdjs.Game_32SceneCode.GDFloresObjects3= [];
gdjs.Game_32SceneCode.GDFloresObjects4= [];
gdjs.Game_32SceneCode.GDConejoGiganteObjects1= [];
gdjs.Game_32SceneCode.GDConejoGiganteObjects2= [];
gdjs.Game_32SceneCode.GDConejoGiganteObjects3= [];
gdjs.Game_32SceneCode.GDConejoGiganteObjects4= [];
gdjs.Game_32SceneCode.GDOjoGarraObjects1= [];
gdjs.Game_32SceneCode.GDOjoGarraObjects2= [];
gdjs.Game_32SceneCode.GDOjoGarraObjects3= [];
gdjs.Game_32SceneCode.GDOjoGarraObjects4= [];
gdjs.Game_32SceneCode.GDZorroObjects1= [];
gdjs.Game_32SceneCode.GDZorroObjects2= [];
gdjs.Game_32SceneCode.GDZorroObjects3= [];
gdjs.Game_32SceneCode.GDZorroObjects4= [];
gdjs.Game_32SceneCode.GDElfoObjects1= [];
gdjs.Game_32SceneCode.GDElfoObjects2= [];
gdjs.Game_32SceneCode.GDElfoObjects3= [];
gdjs.Game_32SceneCode.GDElfoObjects4= [];
gdjs.Game_32SceneCode.GDHumanoObjects1= [];
gdjs.Game_32SceneCode.GDHumanoObjects2= [];
gdjs.Game_32SceneCode.GDHumanoObjects3= [];
gdjs.Game_32SceneCode.GDHumanoObjects4= [];
gdjs.Game_32SceneCode.GDMaestroGremioObjects1= [];
gdjs.Game_32SceneCode.GDMaestroGremioObjects2= [];
gdjs.Game_32SceneCode.GDMaestroGremioObjects3= [];
gdjs.Game_32SceneCode.GDMaestroGremioObjects4= [];
gdjs.Game_32SceneCode.GDDragonObjects1= [];
gdjs.Game_32SceneCode.GDDragonObjects2= [];
gdjs.Game_32SceneCode.GDDragonObjects3= [];
gdjs.Game_32SceneCode.GDDragonObjects4= [];
gdjs.Game_32SceneCode.GDTiendaGremioObjects1= [];
gdjs.Game_32SceneCode.GDTiendaGremioObjects2= [];
gdjs.Game_32SceneCode.GDTiendaGremioObjects3= [];
gdjs.Game_32SceneCode.GDTiendaGremioObjects4= [];
gdjs.Game_32SceneCode.GDBolsaOroObjects1= [];
gdjs.Game_32SceneCode.GDBolsaOroObjects2= [];
gdjs.Game_32SceneCode.GDBolsaOroObjects3= [];
gdjs.Game_32SceneCode.GDBolsaOroObjects4= [];
gdjs.Game_32SceneCode.GDTextoAyudaObjects1= [];
gdjs.Game_32SceneCode.GDTextoAyudaObjects2= [];
gdjs.Game_32SceneCode.GDTextoAyudaObjects3= [];
gdjs.Game_32SceneCode.GDTextoAyudaObjects4= [];


gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].ActivateControl(false, null);
}
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtsExt__CameraShake__SetLayerShakable.func(runtimeScene, true, "Gun Layer", null);
}
{gdjs.evtsExt__CameraShake__SetLayerShakable.func(runtimeScene, true, "Crosshair Layer", null);
}
{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 1.5, "Gun Layer", null);
}
{gdjs.evtsExt__CameraShake__SetLayerZoomAmplitude.func(runtimeScene, 2, "Crosshair Layer", null);
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects = Hashtable.newFrom({"ControlsToggle": gdjs.Game_32SceneCode.GDControlsToggleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBotonHablarObjects1Objects = Hashtable.newFrom({"BotonHablar": gdjs.Game_32SceneCode.GDBotonHablarObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBotonSiguienteObjects1Objects = Hashtable.newFrom({"BotonSiguiente": gdjs.Game_32SceneCode.GDBotonSiguienteObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDObstacleObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPushableBoxObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTerrainObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDSandbagsObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBarrierObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDContainerObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDCrateObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDWaterTankObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDRockObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Game_32SceneCode.GDObstacleObjects1, "PushableBox": gdjs.Game_32SceneCode.GDPushableBoxObjects1, "Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1, "Terrain": gdjs.Game_32SceneCode.GDTerrainObjects1, "Sandbags": gdjs.Game_32SceneCode.GDSandbagsObjects1, "Barrier": gdjs.Game_32SceneCode.GDBarrierObjects1, "Container": gdjs.Game_32SceneCode.GDContainerObjects1, "Crate": gdjs.Game_32SceneCode.GDCrateObjects1, "WaterTank": gdjs.Game_32SceneCode.GDWaterTankObjects1, "Rock": gdjs.Game_32SceneCode.GDRockObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHitParticleObjects1Objects = Hashtable.newFrom({"HitParticle": gdjs.Game_32SceneCode.GDHitParticleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.asyncCallback19387404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects2);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(19387404, gdjs.Game_32SceneCode.asyncCallback19387404);
gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
for (const obj of gdjs.Game_32SceneCode.GDEnemyObjects1) asyncObjectsList.addObject("Enemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback19387404(runtimeScene, asyncObjectsList)), 19387404, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects1, gdjs.Game_32SceneCode.GDEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariableBoolean(gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects2[k] = gdjs.Game_32SceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Rescatar");
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.9, 0, 0.6, null);
}
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects1[k] = gdjs.Game_32SceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(2)).setString("Dying");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].activateBehavior("NavMeshCharacter", false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].getBehavior("Physics3D").setBodyType("Dynamic");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].getBehavior("Physics3D").setFixedRotation(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].getBehavior("Physics3D").applyImpulse(25 * gdjs.evtTools.common.sign((gdjs.Game_32SceneCode.GDEnemyObjects1[i].getCenterXInScene()) - gdjs.evtsExt__Raycaster3D__IntersectionX.func(runtimeScene, null)), 25 * gdjs.evtTools.common.sign((gdjs.Game_32SceneCode.GDEnemyObjects1[i].getCenterYInScene()) - gdjs.evtsExt__Raycaster3D__IntersectionY.func(runtimeScene, null)), 25 * gdjs.evtTools.common.sign((gdjs.Game_32SceneCode.GDEnemyObjects1[i].getBehavior("Object3D").getCenterZInScene()) - gdjs.evtsExt__Raycaster3D__IntersectionZ.func(runtimeScene, null)), gdjs.evtsExt__Raycaster3D__IntersectionX.func(runtimeScene, null), gdjs.evtsExt__Raycaster3D__IntersectionY.func(runtimeScene, null), gdjs.evtsExt__Raycaster3D__IntersectionZ.func(runtimeScene, null));
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects) > 0;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(1)).sub(1);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Game_32SceneCode.GDBarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("Container"), gdjs.Game_32SceneCode.GDContainerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Crate"), gdjs.Game_32SceneCode.GDCrateObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Game_32SceneCode.GDObstacleObjects1);
gdjs.copyArray(runtimeScene.getObjects("PushableBox"), gdjs.Game_32SceneCode.GDPushableBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.Game_32SceneCode.GDRockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sandbags"), gdjs.Game_32SceneCode.GDSandbagsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Terrain"), gdjs.Game_32SceneCode.GDTerrainObjects1);
gdjs.copyArray(runtimeScene.getObjects("WaterTank"), gdjs.Game_32SceneCode.GDWaterTankObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Raycaster3D__RaycastFromCameraCenter.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDObstacleObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPushableBoxObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTerrainObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDSandbagsObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBarrierObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDContainerObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDCrateObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDWaterTankObjects1ObjectsGDgdjs_9546Game_959532SceneCode_9546GDRockObjects1Objects, 2000, null);
if (isConditionTrue_0) {
gdjs.Game_32SceneCode.GDHitParticleObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHitParticleObjects1Objects, gdjs.evtsExt__Raycaster3D__IntersectionX.func(runtimeScene, null), gdjs.evtsExt__Raycaster3D__IntersectionY.func(runtimeScene, null), "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDHitParticleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDHitParticleObjects1[i].getBehavior("Object3D").setZ(gdjs.evtsExt__Raycaster3D__IntersectionZ.func(runtimeScene, null));
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects1);
gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects1);
gdjs.copyArray(runtimeScene.getObjects("ControlsToggle"), gdjs.Game_32SceneCode.GDControlsToggleObjects1);
gdjs.Game_32SceneCode.GDShootButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBotonHablarObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBotonSiguienteObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDShootButtonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Keyboard");
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects2);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Touch");
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDShootButtonObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDShootButtonObjects2[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_2 = true;
        gdjs.Game_32SceneCode.GDShootButtonObjects2[k] = gdjs.Game_32SceneCode.GDShootButtonObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDShootButtonObjects2.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDShootButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDShootButtonObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDShootButtonObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDShootButtonObjects1_1final.push(gdjs.Game_32SceneCode.GDShootButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDShootButtonObjects1_1final, gdjs.Game_32SceneCode.GDShootButtonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19380172);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Gunshot.mp3", false, 50, gdjs.randomFloatInRange(0.95, 1.1));
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.25, 0, 0.2, null);
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects3Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects3});
gdjs.Game_32SceneCode.eventsList7 = function(runtimeScene) {

};gdjs.Game_32SceneCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").pathFound()) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects3[k] = gdjs.Game_32SceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Terrain"), gdjs.Game_32SceneCode.GDTerrainObjects3);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange((( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getAABBLeft()) + (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getWidth()) / 8, (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getAABBRight()) - (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getWidth()) / 8));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(4)).setNumber(gdjs.randomInRange((( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getAABBTop()) + (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getHeight()) / 8, (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getAABBBottom()) - (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].getHeight()) / 8));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").moveTo(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(4).getAsNumber(), (( gdjs.Game_32SceneCode.GDTerrainObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects3[0].GroundZ(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(4).getAsNumber(), null)));
}
}
}

}


};gdjs.Game_32SceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects2, gdjs.Game_32SceneCode.GDEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").pathFound()) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects3[k] = gdjs.Game_32SceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects3 */
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects2, gdjs.Game_32SceneCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(3)).setNumber((( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterXInScene()) + gdjs.randomInRange(-32, 32));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(4)).setNumber((( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterYInScene()) + gdjs.randomInRange(-32, 32));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").moveTo(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(4).getAsNumber(), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getBehavior("Object3D").getZ()));
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects2[i].getBehavior("NavMeshCharacter").pathFound() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects2[k] = gdjs.Game_32SceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects2 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects2[i].resetTimer("PositionChange");
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects4});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects4Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects4});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDObstacleObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPushableBoxObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTerrainObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDSandbagsObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBarrierObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDContainerObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDCrateObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDWaterTankObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDRockObjects4Objects = Hashtable.newFrom({"Obstacle": gdjs.Game_32SceneCode.GDObstacleObjects4, "PushableBox": gdjs.Game_32SceneCode.GDPushableBoxObjects4, "Player": gdjs.Game_32SceneCode.GDPlayerObjects4, "Terrain": gdjs.Game_32SceneCode.GDTerrainObjects4, "Sandbags": gdjs.Game_32SceneCode.GDSandbagsObjects4, "Barrier": gdjs.Game_32SceneCode.GDBarrierObjects4, "Container": gdjs.Game_32SceneCode.GDContainerObjects4, "Crate": gdjs.Game_32SceneCode.GDCrateObjects4, "WaterTank": gdjs.Game_32SceneCode.GDWaterTankObjects4, "Rock": gdjs.Game_32SceneCode.GDRockObjects4});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects4});
gdjs.Game_32SceneCode.eventsList10 = function(runtimeScene) {

};gdjs.Game_32SceneCode.eventsList11 = function(runtimeScene) {

};gdjs.Game_32SceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19399452);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects2, gdjs.Game_32SceneCode.GDEnemyObjects3);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").setMaxSpeed(180);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").moveTo((( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterYInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getBehavior("Object3D").getZ()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].resetTimer("Repath");
}
}
}

}


{

/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects2 */

for (gdjs.Game_32SceneCode.forEachIndex3 = 0;gdjs.Game_32SceneCode.forEachIndex3 < gdjs.Game_32SceneCode.GDEnemyObjects2.length;++gdjs.Game_32SceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.Game_32SceneCode.GDEnemyObjects3.length = 0;


gdjs.Game_32SceneCode.forEachTemporary3 = gdjs.Game_32SceneCode.GDEnemyObjects2[gdjs.Game_32SceneCode.forEachIndex3];
gdjs.Game_32SceneCode.GDEnemyObjects3.push(gdjs.Game_32SceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Repath") >= 0.5 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects3[k] = gdjs.Game_32SceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions((( gdjs.Game_32SceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects3[0].getBehavior("NavMeshCharacter").getDestinationX()), (( gdjs.Game_32SceneCode.GDEnemyObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects3[0].getBehavior("NavMeshCharacter").getDestinationY()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterYInScene())) > 40);
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").setMaxSpeed(180);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").moveTo((( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getCenterYInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects3[0].getBehavior("Object3D").getZ()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].resetTimer("Repath");
}
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Game_32SceneCode.GDEnemyObjects1});
gdjs.Game_32SceneCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.Game_32SceneCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects2);

for (gdjs.Game_32SceneCode.forEachIndex3 = 0;gdjs.Game_32SceneCode.forEachIndex3 < gdjs.Game_32SceneCode.GDEnemyObjects2.length;++gdjs.Game_32SceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.Game_32SceneCode.GDEnemyObjects3.length = 0;


gdjs.Game_32SceneCode.forEachTemporary3 = gdjs.Game_32SceneCode.GDEnemyObjects2[gdjs.Game_32SceneCode.forEachIndex3];
gdjs.Game_32SceneCode.GDEnemyObjects3.push(gdjs.Game_32SceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariableString(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(2)) == "Chasing" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects3[k] = gdjs.Game_32SceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects3Objects, 600, true);
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(2)).setString("Patrolling");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].resetTimer("PositionChange");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].getBehavior("NavMeshCharacter").setMaxSpeed(120);
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariableString(gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)) == "Patrolling" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects2[k] = gdjs.Game_32SceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PositionChange") >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects2[k] = gdjs.Game_32SceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects2[i].getBehavior("NavMeshCharacter").moveTo((( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getCenterYInScene()), (( gdjs.Game_32SceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects2[0].getBehavior("Object3D").getZ()));
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects2);

for (gdjs.Game_32SceneCode.forEachIndex3 = 0;gdjs.Game_32SceneCode.forEachIndex3 < gdjs.Game_32SceneCode.GDEnemyObjects2.length;++gdjs.Game_32SceneCode.forEachIndex3) {
gdjs.Game_32SceneCode.GDBarrierObjects3.length = 0;

gdjs.Game_32SceneCode.GDContainerObjects3.length = 0;

gdjs.Game_32SceneCode.GDCrateObjects3.length = 0;

gdjs.Game_32SceneCode.GDObstacleObjects3.length = 0;

gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;

gdjs.Game_32SceneCode.GDPushableBoxObjects3.length = 0;

gdjs.Game_32SceneCode.GDRockObjects3.length = 0;

gdjs.Game_32SceneCode.GDSandbagsObjects3.length = 0;

gdjs.Game_32SceneCode.GDTerrainObjects3.length = 0;

gdjs.Game_32SceneCode.GDWaterTankObjects3.length = 0;

gdjs.Game_32SceneCode.GDEnemyObjects3.length = 0;


gdjs.Game_32SceneCode.forEachTemporary3 = gdjs.Game_32SceneCode.GDEnemyObjects2[gdjs.Game_32SceneCode.forEachIndex3];
gdjs.Game_32SceneCode.GDEnemyObjects3.push(gdjs.Game_32SceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariableString(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(2)) == "Patrolling" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects3[k] = gdjs.Game_32SceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDBarrierObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDRockObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects3_1final.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects3, gdjs.Game_32SceneCode.GDEnemyObjects4);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects4);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects4Objects, 300, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDEnemyObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDEnemyObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDEnemyObjects3_1final.push(gdjs.Game_32SceneCode.GDEnemyObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPlayerObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDPlayerObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDPlayerObjects3_1final.push(gdjs.Game_32SceneCode.GDPlayerObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.Game_32SceneCode.GDBarrierObjects4);
gdjs.copyArray(runtimeScene.getObjects("Container"), gdjs.Game_32SceneCode.GDContainerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Crate"), gdjs.Game_32SceneCode.GDCrateObjects4);
gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects3, gdjs.Game_32SceneCode.GDEnemyObjects4);

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Game_32SceneCode.GDObstacleObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects4);
gdjs.copyArray(runtimeScene.getObjects("PushableBox"), gdjs.Game_32SceneCode.GDPushableBoxObjects4);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.Game_32SceneCode.GDRockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sandbags"), gdjs.Game_32SceneCode.GDSandbagsObjects4);
gdjs.copyArray(runtimeScene.getObjects("Terrain"), gdjs.Game_32SceneCode.GDTerrainObjects4);
gdjs.copyArray(runtimeScene.getObjects("WaterTank"), gdjs.Game_32SceneCode.GDWaterTankObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__Raycaster3D__RaycastWithAngle.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDObstacleObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPushableBoxObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDTerrainObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDSandbagsObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDBarrierObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDContainerObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDCrateObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDWaterTankObjects4ObjectsGDgdjs_9546Game_959532SceneCode_9546GDRockObjects4Objects, (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getCenterYInScene()), (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getBehavior("Object3D").getCenterZInScene()), (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getAngle()), gdjs.toDegrees(Math.atan(((( gdjs.Game_32SceneCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects4[0].getBehavior("Object3D").getCenterZInScene()) - (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getBehavior("Object3D").getCenterZInScene())) / (( gdjs.Game_32SceneCode.GDEnemyObjects4.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDEnemyObjects4[0].getDistanceToObject((gdjs.Game_32SceneCode.GDPlayerObjects4.length !== 0 ? gdjs.Game_32SceneCode.GDPlayerObjects4[0] : null))))), 1000, null);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.getPickedInstancesCount(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects4Objects) > 0;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDBarrierObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDBarrierObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDBarrierObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDBarrierObjects3_1final.push(gdjs.Game_32SceneCode.GDBarrierObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDContainerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDContainerObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDContainerObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDContainerObjects3_1final.push(gdjs.Game_32SceneCode.GDContainerObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDCrateObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDCrateObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDCrateObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDCrateObjects3_1final.push(gdjs.Game_32SceneCode.GDCrateObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDEnemyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDEnemyObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDEnemyObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDEnemyObjects3_1final.push(gdjs.Game_32SceneCode.GDEnemyObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDObstacleObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDObstacleObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDObstacleObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDObstacleObjects3_1final.push(gdjs.Game_32SceneCode.GDObstacleObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPlayerObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDPlayerObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDPlayerObjects3_1final.push(gdjs.Game_32SceneCode.GDPlayerObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPushableBoxObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPushableBoxObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDPushableBoxObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDPushableBoxObjects3_1final.push(gdjs.Game_32SceneCode.GDPushableBoxObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDRockObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDRockObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDRockObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDRockObjects3_1final.push(gdjs.Game_32SceneCode.GDRockObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDSandbagsObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDSandbagsObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDSandbagsObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDSandbagsObjects3_1final.push(gdjs.Game_32SceneCode.GDSandbagsObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDTerrainObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDTerrainObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDTerrainObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDTerrainObjects3_1final.push(gdjs.Game_32SceneCode.GDTerrainObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDWaterTankObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDWaterTankObjects3_1final.indexOf(gdjs.Game_32SceneCode.GDWaterTankObjects4[j]) === -1 )
            gdjs.Game_32SceneCode.GDWaterTankObjects3_1final.push(gdjs.Game_32SceneCode.GDWaterTankObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDBarrierObjects3_1final, gdjs.Game_32SceneCode.GDBarrierObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDContainerObjects3_1final, gdjs.Game_32SceneCode.GDContainerObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDCrateObjects3_1final, gdjs.Game_32SceneCode.GDCrateObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDEnemyObjects3_1final, gdjs.Game_32SceneCode.GDEnemyObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDObstacleObjects3_1final, gdjs.Game_32SceneCode.GDObstacleObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects3_1final, gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPushableBoxObjects3_1final, gdjs.Game_32SceneCode.GDPushableBoxObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDRockObjects3_1final, gdjs.Game_32SceneCode.GDRockObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDSandbagsObjects3_1final, gdjs.Game_32SceneCode.GDSandbagsObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDTerrainObjects3_1final, gdjs.Game_32SceneCode.GDTerrainObjects3);
gdjs.copyArray(gdjs.Game_32SceneCode.GDWaterTankObjects3_1final, gdjs.Game_32SceneCode.GDWaterTankObjects3);
}
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnemyObjects3[i].returnVariable(gdjs.Game_32SceneCode.GDEnemyObjects3[i].getVariables().getFromIndex(2)).setString("Chasing");
}
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariableString(gdjs.Game_32SceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)) == "Chasing" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects2[k] = gdjs.Game_32SceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Game_32SceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariableString(gdjs.Game_32SceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(2)) != "Dying" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDEnemyObjects1[k] = gdjs.Game_32SceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics3d.haveObjectsStartedColliding(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, "Physics3D", gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDEnemyObjects1Objects, "Physics3D", false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1);
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.5, 0, 0.4, null);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setPosition(-25,1450);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Object3D").setZ(120);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDControlsToggleObjects1, gdjs.Game_32SceneCode.GDControlsToggleObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDControlsToggleObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDControlsToggleObjects2[i].IsChecked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDControlsToggleObjects2[k] = gdjs.Game_32SceneCode.GDControlsToggleObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDControlsToggleObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Touch");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].activateBehavior("MultitouchButton", true);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].activateBehavior("ButtonFSM", true);
}
}
}

}


{

/* Reuse gdjs.Game_32SceneCode.GDControlsToggleObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDControlsToggleObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDControlsToggleObjects1[i].IsChecked(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDControlsToggleObjects1[k] = gdjs.Game_32SceneCode.GDControlsToggleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDControlsToggleObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Keyboard");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects1[i].activateBehavior("MultitouchButton", false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects1[i].activateBehavior("ButtonFSM", false);
}
}
}

}


};gdjs.Game_32SceneCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ControlsToggle"), gdjs.Game_32SceneCode.GDControlsToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDControlsToggleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDControlsToggleObjects1[i].HasJustBeenToggled(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDControlsToggleObjects1[k] = gdjs.Game_32SceneCode.GDControlsToggleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDControlsToggleObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects = Hashtable.newFrom({"ControlsToggle": gdjs.Game_32SceneCode.GDControlsToggleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMovementJoystickObjects2Objects = Hashtable.newFrom({"MovementJoystick": gdjs.Game_32SceneCode.GDMovementJoystickObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMovementJoystickObjects1Objects = Hashtable.newFrom({"MovementJoystick": gdjs.Game_32SceneCode.GDMovementJoystickObjects1});
gdjs.Game_32SceneCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMovementJoystickObjects1Objects, "Left", null));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDJumpButtonObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDJumpButtonObjects1[i].getBehavior("MultitouchButton").IsPressed(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDJumpButtonObjects1[k] = gdjs.Game_32SceneCode.GDJumpButtonObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDShootButtonObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDShootButtonObjects1[i].getBehavior("ButtonFSM").IsPressed(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDShootButtonObjects1[k] = gdjs.Game_32SceneCode.GDShootButtonObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDShootButtonObjects1.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__MousePointerLock__RequestPointerLock.func(runtimeScene, null);
}
}

}


};gdjs.Game_32SceneCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMovementJoystickObjects2Objects, "Left", null);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMovementJoystickObjects2 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].TeleportAndPress(null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19412244);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ControlsToggle"), gdjs.Game_32SceneCode.GDControlsToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Touch");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects, runtimeScene, true, true);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects = Hashtable.newFrom({"ControlsToggle": gdjs.Game_32SceneCode.GDControlsToggleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShootButtonObjects1Objects = Hashtable.newFrom({"ShootButton": gdjs.Game_32SceneCode.GDShootButtonObjects1});
gdjs.Game_32SceneCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ControlsToggle"), gdjs.Game_32SceneCode.GDControlsToggleObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Keyboard");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDControlsToggleObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDShootButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__MousePointerLock__isPointerLocked.func(runtimeScene, null));
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__MousePointerLock__RequestPointerLock.func(runtimeScene, null);
}
}

}


};gdjs.Game_32SceneCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ControlsToggle"), gdjs.Game_32SceneCode.GDControlsToggleObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("Touch");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].ActivateControl(true, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].activateBehavior("MultitouchButton", true);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].activateBehavior("ButtonFSM", true);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDControlsToggleObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDControlsToggleObjects2[i].hide();
}
}
}

}


};gdjs.Game_32SceneCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Touch");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects2[i].ActivateControl(true, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects2[i].activateBehavior("MultitouchButton", true);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects2[i].activateBehavior("ButtonFSM", true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Keyboard");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.Game_32SceneCode.GDMovementJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("ShootButton"), gdjs.Game_32SceneCode.GDShootButtonObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects1[i].ActivateControl(false, null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMovementJoystickObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMovementJoystickObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDShootButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDShootButtonObjects1[i].hide();
}
}
}

}


};gdjs.Game_32SceneCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Buscar");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoMision"), gdjs.Game_32SceneCode.GDTextoMisionObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoMisionObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoMisionObjects2[i].getBehavior("Text").setText("MISION: Encuentra al dragon. Habla con las criaturas y dispara al secuestrador.   Vida: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Rescatar");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoMision"), gdjs.Game_32SceneCode.GDTextoMisionObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoMisionObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoMisionObjects2[i].getBehavior("Text").setText("MISION: El secuestrador cayo! Acercate al dragon y hablale.   Vida: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Sigue");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoMision"), gdjs.Game_32SceneCode.GDTextoMisionObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoMisionObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoMisionObjects2[i].getBehavior("Text").setText("MISION: Lleva al dragon al gremio, al SUR junto al inicio.   Vida: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Entregado");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoMision"), gdjs.Game_32SceneCode.GDTextoMisionObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoMisionObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoMisionObjects1[i].getBehavior("Text").setText("MISION COMPLETADA! El gremio te pago con una bolsa de oro.   Oro: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects = Hashtable.newFrom({"ConejoGigante": gdjs.Game_32SceneCode.GDConejoGiganteObjects3, "Zorro": gdjs.Game_32SceneCode.GDZorroObjects3, "Elfo": gdjs.Game_32SceneCode.GDElfoObjects3, "Humano": gdjs.Game_32SceneCode.GDHumanoObjects3, "OjoGarra": gdjs.Game_32SceneCode.GDOjoGarraObjects3, "MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects = Hashtable.newFrom({"ConejoGigante": gdjs.Game_32SceneCode.GDConejoGiganteObjects3, "Zorro": gdjs.Game_32SceneCode.GDZorroObjects3, "Elfo": gdjs.Game_32SceneCode.GDElfoObjects3, "Humano": gdjs.Game_32SceneCode.GDHumanoObjects3, "OjoGarra": gdjs.Game_32SceneCode.GDOjoGarraObjects3, "MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects = Hashtable.newFrom({"ConejoGigante": gdjs.Game_32SceneCode.GDConejoGiganteObjects3, "Zorro": gdjs.Game_32SceneCode.GDZorroObjects3, "Elfo": gdjs.Game_32SceneCode.GDElfoObjects3, "Humano": gdjs.Game_32SceneCode.GDHumanoObjects3, "OjoGarra": gdjs.Game_32SceneCode.GDOjoGarraObjects3, "MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects = Hashtable.newFrom({"ConejoGigante": gdjs.Game_32SceneCode.GDConejoGiganteObjects3, "Zorro": gdjs.Game_32SceneCode.GDZorroObjects3, "Elfo": gdjs.Game_32SceneCode.GDElfoObjects3, "Humano": gdjs.Game_32SceneCode.GDHumanoObjects3, "OjoGarra": gdjs.Game_32SceneCode.GDOjoGarraObjects3, "MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3Objects = Hashtable.newFrom({"ConejoGigante": gdjs.Game_32SceneCode.GDConejoGiganteObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3Objects = Hashtable.newFrom({"Zorro": gdjs.Game_32SceneCode.GDZorroObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3Objects = Hashtable.newFrom({"Elfo": gdjs.Game_32SceneCode.GDElfoObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3Objects = Hashtable.newFrom({"Humano": gdjs.Game_32SceneCode.GDHumanoObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3Objects = Hashtable.newFrom({"OjoGarra": gdjs.Game_32SceneCode.GDOjoGarraObjects3});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects2Objects = Hashtable.newFrom({"MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects2});
gdjs.Game_32SceneCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ConejoGigante"), gdjs.Game_32SceneCode.GDConejoGiganteObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3Objects, 340, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2, gdjs.Game_32SceneCode.GDBotonHablarObjects3);

gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Conejo Gigante");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Zzz... ayyy... un humano! Hace tres noches vi a un ser oscuro arrastrando al dragon hacia el NORTE, mas alla del arroyo.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Los demonios de ojos rojos vigilan ese camino. Dispara y corre, humano zzz.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zorro"), gdjs.Game_32SceneCode.GDZorroObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3Objects, 340, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2, gdjs.Game_32SceneCode.GDBotonHablarObjects3);

gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Zorro Astuto");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Mis orejas escucharon cadenas y mis patas siguieron el rastro. Vienen del CLARO DEL NORTE.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("El secuestrador es enorme y lleva un colgante rojo. No te acerques demasiado: te mata de un golpe.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Elfo"), gdjs.Game_32SceneCode.GDElfoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3Objects, 340, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2, gdjs.Game_32SceneCode.GDBotonHablarObjects3);

gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Elfo Guardabosques");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("El gremio ya envio a otros dos aventureros... no volvieron. Yo cuidare el bosque por ellos.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Escucha mi consejo: dispara desde lejos y muevete. El dragon esta vivo, lo escucho respirar al norte.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Humano"), gdjs.Game_32SceneCode.GDHumanoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3Objects, 340, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2, gdjs.Game_32SceneCode.GDBotonHablarObjects3);

gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Lenador");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Yo vi la guarida! Piedras grises y setas gigantes, al NORTE del claro. El dragon esta encadenado.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("El que lo secuestro es un demonio muy grande. Con tu arma puedes vencerlo, pero necesita muchos disparos.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("OjoGarra"), gdjs.Game_32SceneCode.GDOjoGarraObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3Objects, 340, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2, gdjs.Game_32SceneCode.GDBotonHablarObjects3);

gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects3);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Ojo de Garras");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Mis tres ojos todo lo ven... el dragon vive, encerrado entre piedras grises al norte. Lo vigila su carcelero.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Cuando el carcelero caiga, el dragon te seguira. Llevalo al gremio del sur y te pagaran con oro.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MaestroGremio"), gdjs.Game_32SceneCode.GDMaestroGremioObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects2Objects, 340, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBotonHablarObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects2);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Maestro del Gremio");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Aventurero! El dragon del gremio fue secuestrado. Lo vieron arrastrarlo hacia el NORTE, a una guarida entre piedras grises.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Habla con las criaturas del bosque, ellas te guiaran. Cuando liberes al dragon, traelo aqui y te pagaremos con una bolsa de oro.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects2[i].hide();
}
}
}

}


};gdjs.Game_32SceneCode.eventsList25 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(2);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoAyuda"), gdjs.Game_32SceneCode.GDTextoAyudaObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects2[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoAyudaObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoAyudaObjects2[i].hide();
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.eventsList26 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.Game_32SceneCode.GDConejoGiganteObjects2.length = 0;

gdjs.Game_32SceneCode.GDElfoObjects2.length = 0;

gdjs.Game_32SceneCode.GDHumanoObjects2.length = 0;

gdjs.Game_32SceneCode.GDMaestroGremioObjects2.length = 0;

gdjs.Game_32SceneCode.GDOjoGarraObjects2.length = 0;

gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;

gdjs.Game_32SceneCode.GDZorroObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ConejoGigante"), gdjs.Game_32SceneCode.GDConejoGiganteObjects3);
gdjs.copyArray(runtimeScene.getObjects("Elfo"), gdjs.Game_32SceneCode.GDElfoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Humano"), gdjs.Game_32SceneCode.GDHumanoObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaestroGremio"), gdjs.Game_32SceneCode.GDMaestroGremioObjects3);
gdjs.copyArray(runtimeScene.getObjects("OjoGarra"), gdjs.Game_32SceneCode.GDOjoGarraObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zorro"), gdjs.Game_32SceneCode.GDZorroObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = !(gdjs.evtsExt__Raycaster3D__RaycastFromCameraCenter.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects, 600, null));
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects, 300, true);
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDConejoGiganteObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.push(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDElfoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDElfoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDElfoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDElfoObjects2_1final.push(gdjs.Game_32SceneCode.GDElfoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDHumanoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDHumanoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDHumanoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDHumanoObjects2_1final.push(gdjs.Game_32SceneCode.GDHumanoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDMaestroGremioObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.push(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDOjoGarraObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.push(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPlayerObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDPlayerObjects2_1final.push(gdjs.Game_32SceneCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDZorroObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDZorroObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDZorroObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDZorroObjects2_1final.push(gdjs.Game_32SceneCode.GDZorroObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final, gdjs.Game_32SceneCode.GDConejoGiganteObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDElfoObjects2_1final, gdjs.Game_32SceneCode.GDElfoObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDHumanoObjects2_1final, gdjs.Game_32SceneCode.GDHumanoObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final, gdjs.Game_32SceneCode.GDMaestroGremioObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final, gdjs.Game_32SceneCode.GDOjoGarraObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects2_1final, gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDZorroObjects2_1final, gdjs.Game_32SceneCode.GDZorroObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects2[i].hide();
}
}
}

}


{

gdjs.Game_32SceneCode.GDConejoGiganteObjects2.length = 0;

gdjs.Game_32SceneCode.GDElfoObjects2.length = 0;

gdjs.Game_32SceneCode.GDHumanoObjects2.length = 0;

gdjs.Game_32SceneCode.GDMaestroGremioObjects2.length = 0;

gdjs.Game_32SceneCode.GDOjoGarraObjects2.length = 0;

gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;

gdjs.Game_32SceneCode.GDZorroObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Touch");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2_1final.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ConejoGigante"), gdjs.Game_32SceneCode.GDConejoGiganteObjects3);
gdjs.copyArray(runtimeScene.getObjects("Elfo"), gdjs.Game_32SceneCode.GDElfoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Humano"), gdjs.Game_32SceneCode.GDHumanoObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaestroGremio"), gdjs.Game_32SceneCode.GDMaestroGremioObjects3);
gdjs.copyArray(runtimeScene.getObjects("OjoGarra"), gdjs.Game_32SceneCode.GDOjoGarraObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zorro"), gdjs.Game_32SceneCode.GDZorroObjects3);
isConditionTrue_1 = gdjs.evtsExt__Raycaster3D__RaycastFromCameraCenter.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects, 600, null);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDConejoGiganteObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.push(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDElfoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDElfoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDElfoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDElfoObjects2_1final.push(gdjs.Game_32SceneCode.GDElfoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDHumanoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDHumanoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDHumanoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDHumanoObjects2_1final.push(gdjs.Game_32SceneCode.GDHumanoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDMaestroGremioObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.push(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDOjoGarraObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.push(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDZorroObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDZorroObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDZorroObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDZorroObjects2_1final.push(gdjs.Game_32SceneCode.GDZorroObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ConejoGigante"), gdjs.Game_32SceneCode.GDConejoGiganteObjects3);
gdjs.copyArray(runtimeScene.getObjects("Elfo"), gdjs.Game_32SceneCode.GDElfoObjects3);
gdjs.copyArray(runtimeScene.getObjects("Humano"), gdjs.Game_32SceneCode.GDHumanoObjects3);
gdjs.copyArray(runtimeScene.getObjects("MaestroGremio"), gdjs.Game_32SceneCode.GDMaestroGremioObjects3);
gdjs.copyArray(runtimeScene.getObjects("OjoGarra"), gdjs.Game_32SceneCode.GDOjoGarraObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zorro"), gdjs.Game_32SceneCode.GDZorroObjects3);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects3Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDConejoGiganteObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDZorroObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDElfoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDHumanoObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDOjoGarraObjects3ObjectsGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects3Objects, 300, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDConejoGiganteObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final.push(gdjs.Game_32SceneCode.GDConejoGiganteObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDElfoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDElfoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDElfoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDElfoObjects2_1final.push(gdjs.Game_32SceneCode.GDElfoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDHumanoObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDHumanoObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDHumanoObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDHumanoObjects2_1final.push(gdjs.Game_32SceneCode.GDHumanoObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDMaestroGremioObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final.push(gdjs.Game_32SceneCode.GDMaestroGremioObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDOjoGarraObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final.push(gdjs.Game_32SceneCode.GDOjoGarraObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPlayerObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDPlayerObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDPlayerObjects2_1final.push(gdjs.Game_32SceneCode.GDPlayerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDZorroObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDZorroObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDZorroObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDZorroObjects2_1final.push(gdjs.Game_32SceneCode.GDZorroObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDConejoGiganteObjects2_1final, gdjs.Game_32SceneCode.GDConejoGiganteObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDElfoObjects2_1final, gdjs.Game_32SceneCode.GDElfoObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDHumanoObjects2_1final, gdjs.Game_32SceneCode.GDHumanoObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDMaestroGremioObjects2_1final, gdjs.Game_32SceneCode.GDMaestroGremioObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDOjoGarraObjects2_1final, gdjs.Game_32SceneCode.GDOjoGarraObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPlayerObjects2_1final, gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDZorroObjects2_1final, gdjs.Game_32SceneCode.GDZorroObjects2);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects2[i].hide(false);
}
}
}

}


{

gdjs.Game_32SceneCode.GDBotonHablarObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects3);
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].IsClicked(null) ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDBotonHablarObjects3[k] = gdjs.Game_32SceneCode.GDBotonHablarObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBotonHablarObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDBotonHablarObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.push(gdjs.Game_32SceneCode.GDBotonHablarObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final, gdjs.Game_32SceneCode.GDBotonHablarObjects2);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList24(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "DialogoWait");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "DialogoWait") > 0.3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "DialogoWait");
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "DialogoWait");
}
}

}


{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TextoAyuda"), gdjs.Game_32SceneCode.GDTextoAyudaObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoAyudaObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoAyudaObjects2[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
gdjs.copyArray(runtimeScene.getObjects("TextoAyuda"), gdjs.Game_32SceneCode.GDTextoAyudaObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoAyudaObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoAyudaObjects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects2Objects = Hashtable.newFrom({"Dragon": gdjs.Game_32SceneCode.GDDragonObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects2Objects = Hashtable.newFrom({"Dragon": gdjs.Game_32SceneCode.GDDragonObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects1Objects = Hashtable.newFrom({"Dragon": gdjs.Game_32SceneCode.GDDragonObjects1});
gdjs.Game_32SceneCode.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Dragon"), gdjs.Game_32SceneCode.GDDragonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Rescatar");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() == "Touch");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects2Objects, 700, false);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects2[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dragon"), gdjs.Game_32SceneCode.GDDragonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects2);
gdjs.Game_32SceneCode.GDBotonHablarObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Rescatar");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects3);
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBotonHablarObjects3[i].IsClicked(null) ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDBotonHablarObjects3[k] = gdjs.Game_32SceneCode.GDBotonHablarObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBotonHablarObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDBotonHablarObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.indexOf(gdjs.Game_32SceneCode.GDBotonHablarObjects3[j]) === -1 )
            gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final.push(gdjs.Game_32SceneCode.GDBotonHablarObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDBotonHablarObjects2_1final, gdjs.Game_32SceneCode.GDBotonHablarObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects2Objects, 700, false);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBotonHablarObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects2);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Dragon Rescatado");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Gracias, aventurero... ese demonio me tenia encadenado entre las piedras. Llevame con el gremio, te lo ruego.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Sigueme! El campamento del gremio esta al sur, junto a donde comenzaste tu busqueda.");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects2[i].hide();
}
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Sigue");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "DragonFollow");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dragon"), gdjs.Game_32SceneCode.GDDragonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Sigue");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDDragonObjects1Objects, 220, true);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDDragonObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Terrain"), gdjs.Game_32SceneCode.GDTerrainObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDragonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDragonObjects1[i].setX(gdjs.Game_32SceneCode.GDDragonObjects1[i].getX() + (((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterXInScene()) - (gdjs.Game_32SceneCode.GDDragonObjects1[i].getCenterXInScene())) * 2 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDragonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDragonObjects1[i].setY(gdjs.Game_32SceneCode.GDDragonObjects1[i].getY() + (((( gdjs.Game_32SceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDPlayerObjects1[0].getCenterYInScene()) - (gdjs.Game_32SceneCode.GDDragonObjects1[i].getCenterYInScene())) * 2 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDragonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDragonObjects1[i].getBehavior("Object3D").setZ((( gdjs.Game_32SceneCode.GDTerrainObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDTerrainObjects1[0].GroundZ((gdjs.Game_32SceneCode.GDDragonObjects1[i].getCenterXInScene()), (gdjs.Game_32SceneCode.GDDragonObjects1[i].getCenterYInScene()), null)));
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects1Objects = Hashtable.newFrom({"MaestroGremio": gdjs.Game_32SceneCode.GDMaestroGremioObjects1});
gdjs.Game_32SceneCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MaestroGremio"), gdjs.Game_32SceneCode.GDMaestroGremioObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "Sigue");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMaestroGremioObjects1Objects, 550, false);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BolsaOro"), gdjs.Game_32SceneCode.GDBolsaOroObjects1);
gdjs.copyArray(runtimeScene.getObjects("BotonHablar"), gdjs.Game_32SceneCode.GDBotonHablarObjects1);
gdjs.copyArray(runtimeScene.getObjects("BotonSiguiente"), gdjs.Game_32SceneCode.GDBotonSiguienteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dragon"), gdjs.Game_32SceneCode.GDDragonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PanelDialogo"), gdjs.Game_32SceneCode.GDPanelDialogoObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextoDialogo"), gdjs.Game_32SceneCode.GDTextoDialogoObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextoNombre"), gdjs.Game_32SceneCode.GDTextoNombreObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("Maestro del Gremio");
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setString("Por los dioses! Has traido de vuelta al dragon. El gremio entero te lo agradece, aventurero.");
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Aqui tienes tu bolsa de oro: 250 monedas. Ya eres una leyenda del bosque!");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPanelDialogoObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPanelDialogoObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoNombreObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoNombreObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTextoDialogoObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTextoDialogoObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonSiguienteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonSiguienteObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBotonHablarObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBotonHablarObjects1[i].hide();
}
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Entregado");
}
{runtimeScene.getGame().getVariables().getFromIndex(1).add(250);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBolsaOroObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBolsaOroObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDDragonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDDragonObjects1[i].activateBehavior("NavMeshCharacter", false);
}
}
}

}


};gdjs.Game_32SceneCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].hide();
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Game_32SceneCode.eventsList6(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList14(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList16(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList19(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList20(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList22(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList23(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList26(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList27(runtimeScene);
}


{


gdjs.Game_32SceneCode.eventsList28(runtimeScene);
}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDObstacleObjects1.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects2.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects3.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects4.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects1.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects2.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects3.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects4.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects3.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects4.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects4.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects4.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects1.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects2.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects3.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects4.length = 0;
gdjs.Game_32SceneCode.GDGunObjects1.length = 0;
gdjs.Game_32SceneCode.GDGunObjects2.length = 0;
gdjs.Game_32SceneCode.GDGunObjects3.length = 0;
gdjs.Game_32SceneCode.GDGunObjects4.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects1.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects2.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects3.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects4.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects4.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects3.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects4.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects1.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects2.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects3.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects4.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects1.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects2.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects3.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects4.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects4.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects1.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects2.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects3.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects4.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects1.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects2.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects3.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects4.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects1.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects2.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects3.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects4.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects1.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects2.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects3.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects4.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects1.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects2.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects3.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects4.length = 0;
gdjs.Game_32SceneCode.GDRockObjects1.length = 0;
gdjs.Game_32SceneCode.GDRockObjects2.length = 0;
gdjs.Game_32SceneCode.GDRockObjects3.length = 0;
gdjs.Game_32SceneCode.GDRockObjects4.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects4.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects1.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects2.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects3.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects4.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects4.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects1.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects2.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects4.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects1.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects2.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects4.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects1.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects2.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects3.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects4.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects1.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects2.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects3.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects4.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects1.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects2.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects3.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects4.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects1.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects2.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects3.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects4.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects1.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects2.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects3.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects4.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects1.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects2.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects3.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects4.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects1.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects2.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects3.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects4.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects1.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects2.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects3.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects4.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects1.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects2.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects3.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects4.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects1.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects2.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects3.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects4.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects1.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects2.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects3.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects4.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects1.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects2.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects3.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects4.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects1.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects2.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects3.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects4.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects1.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects2.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects3.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects4.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects1.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects2.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects3.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects4.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects1.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects2.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects3.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects4.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects1.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects2.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects3.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects4.length = 0;

gdjs.Game_32SceneCode.eventsList29(runtimeScene);
gdjs.Game_32SceneCode.GDObstacleObjects1.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects2.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects3.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects4.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects1.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects2.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects3.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects4.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects3.length = 0;
gdjs.Game_32SceneCode.GDMovementJoystickObjects4.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects4.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects4.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects1.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects2.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects3.length = 0;
gdjs.Game_32SceneCode.GDControlsToggleObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnemyObjects4.length = 0;
gdjs.Game_32SceneCode.GDGunObjects1.length = 0;
gdjs.Game_32SceneCode.GDGunObjects2.length = 0;
gdjs.Game_32SceneCode.GDGunObjects3.length = 0;
gdjs.Game_32SceneCode.GDGunObjects4.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects1.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects2.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects3.length = 0;
gdjs.Game_32SceneCode.GDCrosshairObjects4.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects3.length = 0;
gdjs.Game_32SceneCode.GDShootButtonObjects4.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects1.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects2.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects3.length = 0;
gdjs.Game_32SceneCode.GDHitParticleObjects4.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects1.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects2.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects3.length = 0;
gdjs.Game_32SceneCode.GDTerrainObjects4.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects1.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects2.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects3.length = 0;
gdjs.Game_32SceneCode.GDMapLimitObjects4.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects1.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects2.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects3.length = 0;
gdjs.Game_32SceneCode.GDGrassObjects4.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects1.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects2.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects3.length = 0;
gdjs.Game_32SceneCode.GDSandbagsObjects4.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects1.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects2.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects3.length = 0;
gdjs.Game_32SceneCode.GDBarrierObjects4.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects1.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects2.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects3.length = 0;
gdjs.Game_32SceneCode.GDContainerObjects4.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects1.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects2.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects3.length = 0;
gdjs.Game_32SceneCode.GDCrateObjects4.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects1.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects2.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects3.length = 0;
gdjs.Game_32SceneCode.GDWaterTankObjects4.length = 0;
gdjs.Game_32SceneCode.GDRockObjects1.length = 0;
gdjs.Game_32SceneCode.GDRockObjects2.length = 0;
gdjs.Game_32SceneCode.GDRockObjects3.length = 0;
gdjs.Game_32SceneCode.GDRockObjects4.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects3.length = 0;
gdjs.Game_32SceneCode.GDSmallRocksObjects4.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects1.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects2.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects3.length = 0;
gdjs.Game_32SceneCode.GDCactiObjects4.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlantsObjects4.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects1.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects2.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects3.length = 0;
gdjs.Game_32SceneCode.GDPanelDialogoObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoNombreObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoDialogoObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoMisionObjects4.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects1.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects2.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects3.length = 0;
gdjs.Game_32SceneCode.GDBotonSiguienteObjects4.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects1.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects2.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects3.length = 0;
gdjs.Game_32SceneCode.GDBotonHablarObjects4.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects1.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects2.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects3.length = 0;
gdjs.Game_32SceneCode.GDPinoObjects4.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects1.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects2.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects3.length = 0;
gdjs.Game_32SceneCode.GDRobleObjects4.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects1.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects2.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects3.length = 0;
gdjs.Game_32SceneCode.GDArbustoObjects4.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects1.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects2.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects3.length = 0;
gdjs.Game_32SceneCode.GDSetaObjects4.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects1.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects2.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects3.length = 0;
gdjs.Game_32SceneCode.GDTroncoObjects4.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects1.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects2.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects3.length = 0;
gdjs.Game_32SceneCode.GDHelechosObjects4.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects1.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects2.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects3.length = 0;
gdjs.Game_32SceneCode.GDFloresObjects4.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects1.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects2.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects3.length = 0;
gdjs.Game_32SceneCode.GDConejoGiganteObjects4.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects1.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects2.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects3.length = 0;
gdjs.Game_32SceneCode.GDOjoGarraObjects4.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects1.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects2.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects3.length = 0;
gdjs.Game_32SceneCode.GDZorroObjects4.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects1.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects2.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects3.length = 0;
gdjs.Game_32SceneCode.GDElfoObjects4.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects1.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects2.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects3.length = 0;
gdjs.Game_32SceneCode.GDHumanoObjects4.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects1.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects2.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects3.length = 0;
gdjs.Game_32SceneCode.GDMaestroGremioObjects4.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects1.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects2.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects3.length = 0;
gdjs.Game_32SceneCode.GDDragonObjects4.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects1.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects2.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects3.length = 0;
gdjs.Game_32SceneCode.GDTiendaGremioObjects4.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects1.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects2.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects3.length = 0;
gdjs.Game_32SceneCode.GDBolsaOroObjects4.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects1.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects2.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects3.length = 0;
gdjs.Game_32SceneCode.GDTextoAyudaObjects4.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
